﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

Public Class PersonalizationLevel

    Private _levelID As String
    Public Property LevelID() As String
        Get
            Return _levelID
        End Get
        Set(ByVal value As String)
            _levelID = value
        End Set
    End Property

    Private _description As String
    Public Property Description() As String
        Get
            If Not String.IsNullOrEmpty(_description) Then
                Return _description
            Else
                Return _levelID
            End If
        End Get
        Set(ByVal value As String)
            _description = value
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(ByVal levelID As String, ByVal description As String)
        _levelID = levelID
        _description = description
    End Sub

End Class
