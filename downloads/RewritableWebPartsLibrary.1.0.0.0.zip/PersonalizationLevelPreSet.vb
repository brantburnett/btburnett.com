﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

Friend Class PersonalizationLevelPreSet

    Private _Before As PersonalizationLevelCollection
    Public ReadOnly Property Before() As PersonalizationLevelCollection
        Get
            If _Before Is Nothing Then
                _Before = New PersonalizationLevelCollection()
            End If

            Return _Before
        End Get
    End Property

    Public ReadOnly Property HasBefore() As Boolean
        Get
            Return Not _Before Is Nothing
        End Get
    End Property

    Private _After As PersonalizationLevelCollection
    Public ReadOnly Property After() As PersonalizationLevelCollection
        Get
            If _After Is Nothing Then
                _After = New PersonalizationLevelCollection()
            End If

            Return _After
        End Get
    End Property

    Public ReadOnly Property HasAfter() As Boolean
        Get
            Return Not _After Is Nothing
        End Get
    End Property

End Class
