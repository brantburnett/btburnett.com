﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

Public Class RewritableWebPartManager
    Inherits WebPartManager

    Private _intenalDisplayModeChanging As Boolean = False

    <DesignerSerializationVisibility(DesignerSerializationVisibility.Content)> _
    <PersistenceMode(PersistenceMode.InnerProperty)> _
    <Category("Behavior")> _
    Public ReadOnly Property RewritablePersonalization() As RewritableWebPartPersonalization
        Get
            Return CType(Personalization, RewritableWebPartPersonalization)
        End Get
    End Property

    Protected Overrides Function CreatePersonalization() As System.Web.UI.WebControls.WebParts.WebPartPersonalization
        Return New RewritableWebPartPersonalization(Me)
    End Function

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        If Not Page.PreviousPage Is Nothing AndAlso Not Page.IsCrossPagePostBack Then
            Dim previousMgr As WebPartManager = WebPartManager.GetCurrentWebPartManager(Page.PreviousPage)
            If Not previousMgr Is Nothing AndAlso TypeOf previousMgr Is RewritableWebPartManager Then
                InternalSetDisplayMode(previousMgr.DisplayMode)
            End If
        End If
    End Sub

    Protected Overrides Sub OnDisplayModeChanged(ByVal e As System.Web.UI.WebControls.WebParts.WebPartDisplayModeEventArgs)
        If Not _intenalDisplayModeChanging Then
            If e.OldDisplayMode Is BrowseDisplayMode Then
                CType(Personalization, RewritableWebPartPersonalization).TransferToCurrentPage(Page)
            ElseIf DisplayMode Is BrowseDisplayMode Then
                CType(Personalization, RewritableWebPartPersonalization).TransferToCurrentPage(Page)
            Else
                MyBase.OnDisplayModeChanged(e)
            End If
        Else
            MyBase.OnDisplayModeChanged(e)
        End If

        If DisplayMode Is BrowseDisplayMode Then
            Page.ClientScript.RegisterHiddenField("__RWWPPM", "b")
        Else
            Page.ClientScript.RegisterHiddenField("__RWWPPM", "d")
        End If
    End Sub

    Friend Sub InternalSetDisplayMode(ByVal displayMode As WebPartDisplayMode)
        _intenalDisplayModeChanging = True
        Try
            Me.DisplayMode = displayMode
        Finally
            _intenalDisplayModeChanging = False
        End Try
    End Sub

    Public Shared Shadows Function GetCurrentWebPartManager(ByVal page As Page) As RewritableWebPartManager
        Dim mgr As WebPartManager = WebPartManager.GetCurrentWebPartManager(page)
        If TypeOf mgr Is RewritableWebPartManager Then
            Return mgr
        Else
            Return Nothing
        End If
    End Function

    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        Dim levels As PersonalizationLevelPreSet = Page.Items(Me.GetType())
        If Not levels Is Nothing Then
            If levels.HasBefore Then
                RewritablePersonalization.PersonalizationLevels.InsertRange(0, levels.Before)
            End If
            If levels.HasAfter Then
                RewritablePersonalization.PersonalizationLevels.AddRange(levels.After)
            End If
        End If

        MyBase.OnInit(e)
    End Sub

    Public Shared Sub RegisterPersonalizationLevel(ByVal page As Page, ByVal level As PersonalizationLevel)
        RegisterPersonalizationLevel(page, level, False)
    End Sub

    Public Shared Sub RegisterPersonalizationLevel(ByVal page As Page, ByVal level As PersonalizationLevel, ByVal insertAtBeginning As Boolean)
        If page Is Nothing Then
            Throw New ArgumentNullException("page")
        End If
        If level Is Nothing Then
            Throw New ArgumentNullException("level")
        End If

        Dim levels As PersonalizationLevelPreSet = page.Items(GetType(RewritableWebPartManager))
        If levels Is Nothing Then
            levels = New PersonalizationLevelPreSet()
            page.Items(GetType(RewritableWebPartManager)) = levels
        End If

        If insertAtBeginning Then
            levels.Before.Insert(0, level)
        Else
            levels.After.Add(level)
        End If
    End Sub

End Class
