﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

Public Class RewritableSqlPersonalizationProvider
    Inherits SqlPersonalizationProvider

    Protected Overrides Sub LoadPersonalizationBlobs(ByVal webPartManager As System.Web.UI.WebControls.WebParts.WebPartManager, ByVal path As String, ByVal userName As String, ByRef sharedDataBlob() As Byte, ByRef userDataBlob() As Byte)
        If TypeOf webPartManager Is RewritableWebPartManager Then
            Dim personalization As RewritableWebPartPersonalization = webPartManager.Personalization

            Dim page As Page = webPartManager.Page
            Dim id As String = Nothing
            Dim modeType As String = "b"

            If page.IsPostBack Then
                id = page.Request("__RWWPPS")
                modeType = page.Request("__RWWPPM")
            Else
                If Not page.PreviousPage Is Nothing AndAlso Not page.IsCrossPagePostBack Then
                    Dim previousMgr As WebPartManager = webPartManager.GetCurrentWebPartManager(page.PreviousPage)
                    If Not previousMgr Is Nothing AndAlso TypeOf previousMgr Is RewritableWebPartManager Then
                        Dim previousPersonalization As RewritableWebPartPersonalization = previousMgr.Personalization
                        Dim level As PersonalizationLevel = previousPersonalization.PersonalizationLevel
                        If Not level Is Nothing Then
                            id = level.LevelID
                        End If

                        If Not previousMgr.DisplayMode Is webPartManager.BrowseDisplayMode Then
                            modeType = "d"
                        End If
                    End If
                End If
            End If

            If Not String.IsNullOrEmpty(id) Then
                personalization.SetLevel(id)
                page.ClientScript.RegisterHiddenField("__RWWPPS", id)
            Else
                page.ClientScript.RegisterHiddenField("__RWWPPS", String.Empty)
            End If
            page.ClientScript.RegisterHiddenField("__RWWPPM", modeType)

            If modeType = "b" Then
                sharedDataBlob = Nothing
                userDataBlob = Nothing
                MyBase.LoadPersonalizationBlobs(webPartManager, GetPageUrl(webPartManager), userName, sharedDataBlob, userDataBlob)
                If Not sharedDataBlob Is Nothing OrElse Not userDataBlob Is Nothing Then
                    Exit Sub
                End If

                For Each level As PersonalizationLevel In personalization.PersonalizationLevels
                    sharedDataBlob = Nothing
                    userDataBlob = Nothing
                    MyBase.LoadPersonalizationBlobs(webPartManager, "!" & level.LevelID, userName, sharedDataBlob, userDataBlob)

                    If Not sharedDataBlob Is Nothing OrElse Not userDataBlob Is Nothing Then
                        Exit Sub
                    End If
                Next
            Else
                If personalization.PersonalizationLevel Is Nothing Then
                    MyBase.LoadPersonalizationBlobs(webPartManager, GetPageUrl(webPartManager), userName, sharedDataBlob, userDataBlob)
                Else
                    MyBase.LoadPersonalizationBlobs(webPartManager, "!" & personalization.PersonalizationLevel.LevelID, userName, sharedDataBlob, userDataBlob)
                End If
            End If
        Else
            MyBase.LoadPersonalizationBlobs(webPartManager, path, userName, sharedDataBlob, userDataBlob)
        End If
    End Sub

    Protected Overrides Sub SavePersonalizationBlob(ByVal webPartManager As System.Web.UI.WebControls.WebParts.WebPartManager, ByVal path As String, ByVal userName As String, ByVal dataBlob() As Byte)
        If TypeOf webPartManager Is RewritableWebPartManager Then
            Dim personalization As RewritableWebPartPersonalization = webPartManager.Personalization

            If personalization.PersonalizationLevel Is Nothing Then
                MyBase.SavePersonalizationBlob(webPartManager, GetPageUrl(webPartManager), userName, dataBlob)
            Else
                MyBase.SavePersonalizationBlob(webPartManager, "!" & personalization.PersonalizationLevel.LevelID, userName, dataBlob)
            End If
        Else
            MyBase.SavePersonalizationBlob(webPartManager, path, userName, dataBlob)
        End If
    End Sub

    Protected Overrides Sub ResetPersonalizationBlob(ByVal webPartManager As System.Web.UI.WebControls.WebParts.WebPartManager, ByVal path As String, ByVal userName As String)
        If TypeOf webPartManager Is RewritableWebPartManager Then
            Dim personalization As RewritableWebPartPersonalization = webPartManager.Personalization

            If personalization.PersonalizationLevel Is Nothing Then
                MyBase.ResetPersonalizationBlob(webPartManager, GetPageUrl(webPartManager), userName)
            Else
                MyBase.ResetPersonalizationBlob(webPartManager, "!" & personalization.PersonalizationLevel.LevelID, userName)
            End If
        Else
            MyBase.ResetPersonalizationBlob(webPartManager, path, userName)
        End If
    End Sub

    Private Function GetPageUrl(ByVal webPartManager As WebPartManager)
        Dim url As String = webPartManager.Page.Request.RawUrl
        Dim index As Integer = url.IndexOf("?"c)
        If index >= 0 Then
            url = url.Substring(0, index)
        End If

        Return VirtualPathUtility.ToAppRelative(url)
    End Function

End Class
