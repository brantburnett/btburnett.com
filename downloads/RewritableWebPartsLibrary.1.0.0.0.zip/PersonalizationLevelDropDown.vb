﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

<ToolboxData("<{0}:PersonalizationLevelDropDown runat=server></{0}:PersonalizationLevelDropDown>")> _
Public Class PersonalizationLevelDropDown
    Inherits DropDownList

    Public Sub New()
        AutoPostBack = True
    End Sub

    Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
        Dim scriptManager As ScriptManager = scriptManager.GetCurrent(Page)
        If Not scriptManager Is Nothing Then
            scriptManager.RegisterPostBackControl(Me)
        End If

        Items.Clear()
        Items.Add(New ListItem("This Page", String.Empty))

        Dim mgr As RewritableWebPartManager = RewritableWebPartManager.GetCurrentWebPartManager(Page)
        If Not mgr Is Nothing AndAlso mgr.RewritablePersonalization.IsEnabled Then
            Dim personalization As RewritableWebPartPersonalization = mgr.RewritablePersonalization
            For Each level As PersonalizationLevel In personalization.PersonalizationLevels
                Items.Add(New ListItem(level.Description, level.LevelID))
            Next

            If personalization.PersonalizationLevel Is Nothing Then
                SelectedValue = String.Empty
            Else
                SelectedValue = personalization.PersonalizationLevel.LevelID
            End If
        Else
            SelectedValue = String.Empty
        End If

        MyBase.OnPreRender(e)
    End Sub

    Protected Overrides Sub OnSelectedIndexChanged(ByVal e As System.EventArgs)
        Dim mgr As RewritableWebPartManager = RewritableWebPartManager.GetCurrentWebPartManager(Page)
        If Not mgr Is Nothing AndAlso mgr.RewritablePersonalization.IsEnabled Then
            mgr.RewritablePersonalization.ChangeLevel(SelectedValue)
        End If

        MyBase.OnSelectedIndexChanged(e)
    End Sub

End Class
