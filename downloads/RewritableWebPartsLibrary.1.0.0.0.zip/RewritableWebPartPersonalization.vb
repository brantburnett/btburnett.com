﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

<ParseChildren(GetType(PersonalizationLevel), ChildrenAsProperties:=True, DefaultProperty:="PersonalizationLevels")> _
Public Class RewritableWebPartPersonalization
    Inherits WebPartPersonalization

    Private _personalizationLevels As PersonalizationLevelCollection
    <DesignerSerializationVisibility(DesignerSerializationVisibility.Content)> _
    <PersistenceMode(PersistenceMode.InnerProperty)> _
    Public ReadOnly Property PersonalizationLevels() As PersonalizationLevelCollection
        Get
            If _personalizationLevels Is Nothing Then
                _personalizationLevels = New PersonalizationLevelCollection()
            End If

            Return _personalizationLevels
        End Get
    End Property

    Private _personalizationLevel As PersonalizationLevel
    <Browsable(False)> _
    Public ReadOnly Property PersonalizationLevel() As PersonalizationLevel
        Get
            Return _personalizationLevel
        End Get
    End Property

    Public ReadOnly Property PersonalizationLevelId() As String
        Get
            If _personalizationLevel Is Nothing Then
                Return String.Empty
            Else
                Return _personalizationLevel.LevelID
            End If
        End Get
    End Property

    Public Sub New(ByVal owner As RewritableWebPartManager)
        MyBase.New(owner)
    End Sub

    Friend Sub SetLevel(ByVal levelID As String)
        If Not String.IsNullOrEmpty(levelID) Then
            Dim level As PersonalizationLevel = Nothing
            For Each level2 As PersonalizationLevel In PersonalizationLevels
                If level2.LevelID = levelID Then
                    level = level2
                    Exit For
                End If
            Next
            If level Is Nothing Then
                Throw New ArgumentException("Level Not Found")
            End If

            _personalizationLevel = level
        Else
            _personalizationLevel = Nothing
        End If
    End Sub

    Public Sub ChangeLevel(ByVal levelID As String)
        EnsureEnabled(False)
        If WebPartManager.Page Is Nothing Then
            Throw New InvalidOperationException("WebPartManager.Page Cannot Be Null")
        End If

        SetLevel(levelID)

        TransferToCurrentPage(WebPartManager.Page)
    End Sub

    Friend Sub TransferToCurrentPage(ByVal page As Page)
        Dim request As HttpRequest = page.Request
        If request Is Nothing Then
            Throw New InvalidOperationException("WebPartManager.Page.Request Cannot Be Null")
        End If

        Dim url As String = request.CurrentExecutionFilePath
        If page.Form Is Nothing OrElse String.Equals(page.Form.Method, "post", StringComparison.OrdinalIgnoreCase) Then
            Dim queryString As String = page.ClientQueryString
            If Not String.IsNullOrEmpty(queryString) Then
                url = String.Concat(url, "?", queryString)
            End If
        End If

        Dim scriptManager As ScriptManager = System.Web.UI.ScriptManager.GetCurrent(page)
        If Not scriptManager Is Nothing AndAlso scriptManager.IsInAsyncPostBack Then
            page.Response.Redirect(url)
        Else
            page.Server.Transfer(url, False)
        End If
    End Sub

End Class
