﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' RewritableWebPartsLibrary is distributed under the terms of the GNU Lesser General Public License (GPL)

' RewritableWebPartsLibrary is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' RewritableWebPartsLibrary is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with RewritableWebPartsLibrary.  If not, see <http://www.gnu.org/licenses/>.

Public Class PersonalizationLevelCollection
    Inherits Collection(Of PersonalizationLevel)

    Public Sub InsertRange(ByVal index As Integer, ByVal range As PersonalizationLevelCollection)
        For i As Integer = range.Count - 1 To 0 Step -1
            Insert(index, range(i))
        Next
    End Sub

    Public Sub AddRange(ByVal range As PersonalizationLevelCollection)
        For Each level As PersonalizationLevel In range
            Add(level)
        Next
    End Sub

End Class
