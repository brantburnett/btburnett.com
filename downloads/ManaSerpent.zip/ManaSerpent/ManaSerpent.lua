-- Initialization

local AceConfig = LibStub("AceConfig-3.0")
ManaSerpent = LibStub("AceAddon-3.0"):NewAddon("ManaSerpent", "AceConsole-3.0", "AceEvent-3.0")
local L = LibStub('AceLocale-3.0'):GetLocale('ManaSerpent')

-- Options

local options = {
	name = "ManaSerpent",
	handler = ManaSerpent,
	type = 'group',
	args = {
		enabled = {
			order = 0,
			name = L["ENABLED"],
			desc = L["ENABLEDDESC"],
			type = "toggle",
			width = "full",
			set = "SetEnabled",
			get = "GetEnabled"
		},
		combatLow = {
			order = 1,
			name = L["COMBATLOW"],
			desc = L["COMBATLOWDESC"],
			type = "range",
			min = 0,
			max = 1.0,
			step = 0.01,
			isPercent = true,
			set = "SetCombatLow",
			get = "GetCombatLow",
		},
		combatHigh = {
			order = 2,
			name = L["COMBATHIGH"],
			desc = L["COMBATHIGHDESC"],
			type = "range",
			min = 0,
			max = 1.0,
			step = 0.01,
			isPercent = true,
			set = "SetCombatHigh",
			get = "GetCombatHigh",
		},
		noncombatLow = {
			order = 3,
			name = L["NONCOMBATLOW"],
			desc = L["NONCOMBATLOWDESC"],
			type = "range",
			min = 0,
			max = 1.0,
			step = 0.01,
			isPercent = true,
			set = "SetNonCombatLow",
			get = "GetNonCombatLow",
		},
		noncombatHigh = {
			order = 4,
			name = L["NONCOMBATHIGH"],
			desc = L["NONCOMBATHIGHDESC"],
			type = "range",
			min = 0,
			max = 1.0,
			step = 0.01,
			isPercent = true,
			set = "SetNonCombatHigh",
			get = "GetNonCombatHigh",
		},
		autoOffStart = {
			order = 5,
			name = L["AUTOOFFSTART"],
			desc = L["AUTOOFFSTARTDESC"],
			type = "toggle",
			width = "full",
			set = "SetAutoOffStart",
			get = "GetAutoOffStart"
		},
		autoOffHigh = {
			order = 6,
			name = L["AUTOOFFHIGH"],
			desc = L["AUTOOFFHIGHDESC"],
			type = "toggle",
			width = "full",
			set = "SetAutoOffHigh",
			get = "GetAutoOffHigh"
		},
		playSound = {
			order = 7,
			name = L["PLAYSOUND"],
			desc = L["PLAYSOUNDDESC"],
			type = "toggle",
			width = "full",
			set = "SetPlaySound",
			get = "GetPlaySound"
		}
	}
}

local defaults = {
	profile = {
		enabled = true,
		combatLow = 0.15,
		noncombatLow = 0.30,
		combatHigh = 1.0,
		noncombatHigh = 1.0,
		autoOffStart = true,
		autoOffHigh = true,
		playSound = true
	}
}

-- Functionality

function ManaSerpent:OnInitialize()
	local localizedClass, englishClass = UnitClass("player")
	if englishClass == "HUNTER" then
		self.isHunter = true
		self.db = LibStub("AceDB-3.0"):New("ManaSerpentDB", defaults)
		
		AceConfig:RegisterOptionsTable("ManaSerpent", options)
		self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("ManaSerpent", "ManaSerpent")
		
		AceConfig:RegisterOptionsTable("ManaSerpentProfiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db))
		self.profileFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("ManaSerpentProfiles", "Profiles", "ManaSerpent")

		self:RegisterChatCommand("manaserpent", 'ChatCommand')
	end
end

function ManaSerpent:OnEnable()
	if not self.isHunter then return end
	if self.db.profile.enabled then
		self:EnableManaSerpent()
	end
end

function ManaSerpent:EnableManaSerpent()
	if not self.isHunter then return end
	self.db.profile.enabled = true
	
	self.alertedLow = true
	self.alertedHigh = true

	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	self:RegisterEvent("UNIT_MANA")
	self:RegisterEvent("UNIT_MAXMANA")
end

function ManaSerpent:DisableManaSerpent()
	if not self.isHunter then return end
	self.db.profile.enabled = false

	self:UnregisterEvent("PLAYER_REGEN_ENABLED")
	self:UnregisterEvent("PLAYER_REGEN_DISABLED")
	self:UnregisterEvent("UNIT_MANA")
	self:UnregisterEvent("UNIT_MAXMANA")
end

function ManaSerpent:ChatCommand(input)
	if input == "on" then
		self:Enable()
		self:Print("ManaSerpent enabled")
	elseif input == "off" then
		self:Disable()
		self:Print("ManaSerpent disabled")
	else
		InterfaceOptionsFrame_OpenToCategory("ManaSerpent")
	end
end

-- Events

function ManaSerpent:PLAYER_REGEN_ENABLED()
	self:UpdateMana()
end

function ManaSerpent:PLAYER_REGEN_DISABLED()
	self.alertedLow = self:GetManaPercent() < self.db.profile.combatLow
	
	if self:IsViper() then
		if self.db.profile.autoOffStart then
			CancelUnitBuff('player', L['VIPER'])
		end
		
		self:Alert(L['OFF'])
	end
end

function ManaSerpent:UNIT_MANA(e, unit)
	if (unit == 'player') and not UnitIsDeadOrGhost('player') then
		self:UpdateMana()
	end
end

function ManaSerpent:UNIT_MAXMANA(e, unit)
	if (unit == 'player') and not UnitIsDeadOrGhost('player') then
		self:UpdateMana()
	end
end

-- Processing

function ManaSerpent:UpdateMana()
	local percent = self:GetManaPercent()
	
	local minimum, maximum
	if InCombatLockdown() then
		minimum = self.db.profile.combatLow
		maximum = self.db.profile.combatHigh
	else
		minimum = self.db.profile.noncombatLow
		maximum = self.db.profile.noncombatHigh
	end

	if percent >= maximum then
		if not self.alertedHigh then
			self.alertedHigh = true
			self.alertedLow = false
			
			if self:IsViper() then
				if self.db.profile.autoOffHigh then
					CancelUnitBuff('player', L['VIPER'])
				end
				
				self:Alert(L['OFF'])
			end
		end
	else
		self.alertedHigh = false
		
		if percent < minimum then
			if not self.alertedLow then
				self.alertedLow = true
				
				if not self:IsViper() then
					self:Alert(L['LOW'])
				end
			end
		else
			self.alertedLow = false
		end
	end
end

function ManaSerpent:GetManaPercent()
	local mana = UnitPower('player')
	local maxMana = UnitPowerMax('player')
	
	return mana / maxMana
end

function ManaSerpent:IsViper()
	if UnitBuff('player', L['VIPER']) then
		return true
	else
		return false
	end
end

function ManaSerpent:Alert(msg)
	RaidNotice_AddMessage(RaidWarningFrame, msg, ChatTypeInfo["RAID_WARNING"])
	
	if self.db.profile.playSound then
		PlaySoundFile("Sound\\Spells\\PVPFlagTaken.wav")
	end
end

function ManaSerpent:GetEnabled(info)
	return self.db.profile.enabled
end

function ManaSerpent:SetEnabled(info, input)
	if input ~= self.db.profile.enabled then
		if input then
			self:EnableManaSerpent()
		else
			self:DisableManaSerpent()
		end
	end
end

function ManaSerpent:GetCombatLow(info)
	return self.db.profile.combatLow
end

function ManaSerpent:SetCombatLow(info, input)
	self.db.profile.combatLow = input
end

function ManaSerpent:GetCombatHigh(info)
	return self.db.profile.combatHigh
end

function ManaSerpent:SetCombatHigh(info, input)
	self.db.profile.combatHigh = input
end

function ManaSerpent:GetNonCombatLow(info)
	return self.db.profile.noncombatLow
end

function ManaSerpent:SetNonCombatLow(info, input)
	self.db.profile.noncombatLow = input
end

function ManaSerpent:GetNonCombatHigh(info)
	return self.db.profile.noncombatHigh
end

function ManaSerpent:SetNonCombatHigh(info, input)
	self.db.profile.noncombatHigh = input
end

function ManaSerpent:GetAutoOffStart(info)
	return self.db.profile.autoOffStart
end

function ManaSerpent:SetAutoOffStart(info, input)
	self.db.profile.autoOffStart = input
end

function ManaSerpent:GetAutoOffHigh(info)
	return self.db.profile.autoOffHigh
end

function ManaSerpent:SetAutoOffHigh(info, input)
	self.db.profile.autoOffHigh = input
end

function ManaSerpent:GetPlaySound(info)
	return self.db.profile.playSound
end

function ManaSerpent:SetPlaySound(info, input)
	self.db.profile.playSound = input
end
