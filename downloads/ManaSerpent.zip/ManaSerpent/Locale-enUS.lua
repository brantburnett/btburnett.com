local L = LibStub("AceLocale-3.0"):NewLocale("ManaSerpent", "enUS", true)

if L then
	L["VIPER"] = "Aspect of the Viper"
	L["OFF"] = "*** Activate New Aspect ***"
	L["LOW"] = "*** Low Mana, Activate Aspect of the Viper ***"
	
	L["ENABLED"] = "Enabled"
	L["ENABLEDDESC"] = "ManaSerpent is enabled"

	L["COMBATLOW"] = "Combat Low"
	L["COMBATLOWDESC"] = "Alert when mana falls below this level while in combat"
	
	L["COMBATHIGH"] = "Combat High"
	L["COMBATHIGHDESC"] = "Turn off Aspect of the Viper when mana is refilled to this level while in combat"
	
	L["NONCOMBATLOW"] = "Non-Combat Low"
	L["NONCOMBATLOWDESC"] = "Alert when mana is below this level when leaving combat"
	
	L["NONCOMBATHIGH"] = "Non-Combat High"
	L["NONCOMBATHIGHDESC"] = "Turn off Aspect of the Viper when mana is refilled to this level while not in combat"
	
	L["AUTOOFFSTART"] = "Auto Off On Combat Start"
	L["AUTOOFFSTARTDESC"] = "Automatically turn off Aspect of the Viper when combat starts"

	L["AUTOOFFHIGH"] = "Auto Off On High Mana"
	L["AUTOOFFHIGHDESC"] = "Automatically turn off Aspect of the Viper when the high mana threshold is reached"
	
	L["PLAYSOUND"] = "Play Sound"
	L["PLAYSOUNDDESC"] = "Play sound when alerts are shown"
end
