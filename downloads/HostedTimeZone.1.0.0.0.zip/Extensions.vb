﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' HostedTimeZone is distributed under the terms of the GNU Lesser General Public License (GPL)

' HostedTimeZone is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' HostedTimeZone is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with HostedTimeZone.  If not, see <http://www.gnu.org/licenses/>.

Imports System.Runtime.CompilerServices

<Extension()> _
Public Module Extensions

    ''' <summary>
    ''' Converts a DateTime from the local time zone to the application time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the application time zone</param>
    ''' <returns>Converted DateTime</returns>
    <Extension()> _
    Public Function ToAppTime(ByVal dateTime As DateTime) As DateTime
        Return ApplicationTimeZone.ToAppTime(dateTime)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the application time zone to the local time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the local time zone</param>
    ''' <returns>Converted DateTime</returns>
    <Extension()> _
    Public Function FromAppTime(ByVal dateTime As DateTime) As DateTime
        Return ApplicationTimeZone.FromAppTime(dateTime)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the thread time zone</param>
    ''' <returns>Converted DateTime</returns>
    <Extension()> _
    Public Function ToThreadTime(ByVal dateTime As DateTime) As DateTime
        Return ApplicationTimeZone.ToThreadTime(dateTime)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the thread time zone to the local time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the local time zone</param>
    ''' <returns>Converted DateTime</returns>
    <Extension()> _
    Public Function FromThreadTime(ByVal dateTime As DateTime) As DateTime
        Return ApplicationTimeZone.FromThreadTime(dateTime)
    End Function

    ''' <summary>
    ''' Converts a DateTimeOffset from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTimeOffset">DateTimeOffset to convert to the thread time zone</param>
    ''' <returns>Converted DateTimeOffset</returns>
    <Extension()> _
    Public Function ToAppTime(ByVal dateTimeOffset As DateTimeOffset) As DateTimeOffset
        Return ApplicationTimeZone.ToAppTime(dateTimeOffset)
    End Function

    ''' <summary>
    ''' Converts a DateTimeOffset from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTimeOffset">DateTimeOffset to convert to the thread time zone</param>
    ''' <returns>Converted DateTimeOffset</returns>
    <Extension()> _
    Public Function ToThreadTime(ByVal dateTimeOffset As DateTimeOffset) As DateTimeOffset
        Return ApplicationTimeZone.ToThreadTime(dateTimeOffset)
    End Function

End Module
