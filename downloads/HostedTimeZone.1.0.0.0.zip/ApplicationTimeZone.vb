﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' Written by Brant Burnett <mailto:btburnett3@gmail.com>
' HostedTimeZone is distributed under the terms of the GNU Lesser General Public License (GPL)

' HostedTimeZone is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' HostedTimeZone is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with HostedTimeZone.  If not, see <http://www.gnu.org/licenses/>.

Public NotInheritable Class ApplicationTimeZone

    Private Sub New()
        Throw New NotImplementedException()
    End Sub

    Private Shared _applicationTimeZone As TimeZoneInfo = TimeZoneInfo.Local

    ''' <summary>
    ''' Time zone to be used by the ToAppTime and FromAppTime methods
    ''' </summary>
    Public Shared Property ApplicationTimeZone() As TimeZoneInfo
        Get
            Return _applicationTimeZone
        End Get
        Set(ByVal value As TimeZoneInfo)
            If value Is Nothing Then Throw New ArgumentNullException("value")
            _applicationTimeZone = value
        End Set
    End Property

    <ThreadStatic()> _
    Private Shared _threadTimeZone As TimeZoneInfo = Nothing

    ''' <summary>
    ''' Time zone to be used by the ToThreadTime and FromThreadTime methods
    ''' </summary>
    ''' <remarks>If not set for a thread, ThreadTimeZone defaults to the ApplicationTimeZone</remarks>
    Public Shared Property ThreadTimeZone() As TimeZoneInfo
        Get
            If _threadTimeZone Is Nothing Then
                Return _applicationTimeZone
            Else
                Return _threadTimeZone
            End If
        End Get
        Set(ByVal value As TimeZoneInfo)
            _threadTimeZone = value
        End Set
    End Property

    ''' <summary>
    ''' Converts a DateTime from the local time zone to the application time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the application time zone</param>
    ''' <returns>Converted DateTime</returns>
    Public Shared Function ToAppTime(ByVal dateTime As DateTime) As DateTime
        Return TimeZoneInfo.ConvertTime(dateTime, _applicationTimeZone)
    End Function

    ''' <summary>
    ''' Converts a DateTimeOffset from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTimeOffset">DateTimeOffset to convert to the thread time zone</param>
    ''' <returns>Converted DateTimeOffset</returns>
    Public Shared Function ToAppTime(ByVal dateTimeOffset As DateTimeOffset) As DateTimeOffset
        Return TimeZoneInfo.ConvertTime(dateTimeOffset, _applicationTimeZone)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the application time zone to the local time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the local time zone</param>
    ''' <returns>Converted DateTime</returns>
    Public Shared Function FromAppTime(ByVal dateTime As DateTime) As DateTime
        Return TimeZoneInfo.ConvertTime(dateTime, _applicationTimeZone, TimeZoneInfo.Local)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the thread time zone</param>
    ''' <returns>Converted DateTime</returns>
    Public Shared Function ToThreadTime(ByVal dateTime As DateTime) As DateTime
        Return TimeZoneInfo.ConvertTime(dateTime, ThreadTimeZone)
    End Function

    ''' <summary>
    ''' Converts a DateTimeOffset from the local time zone to the thread time zone
    ''' </summary>
    ''' <param name="dateTimeOffset">DateTimeOffset to convert to the thread time zone</param>
    ''' <returns>Converted DateTimeOffset</returns>
    Public Shared Function ToThreadTime(ByVal dateTimeOffset As DateTimeOffset) As DateTimeOffset
        Return TimeZoneInfo.ConvertTime(dateTimeOffset, ThreadTimeZone)
    End Function

    ''' <summary>
    ''' Converts a DateTime from the thread time zone to the local time zone
    ''' </summary>
    ''' <param name="dateTime">DateTime to convert to the local time zone</param>
    ''' <returns>Converted DateTime</returns>
    Public Shared Function FromThreadTime(ByVal dateTime As DateTime) As DateTime
        Return TimeZoneInfo.ConvertTime(dateTime, ThreadTimeZone, TimeZoneInfo.Local)
    End Function

End Class
