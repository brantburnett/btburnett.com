﻿Public Enum SslRequirement
    None = 0
    [Optional] = 1
    Required = 2
End Enum