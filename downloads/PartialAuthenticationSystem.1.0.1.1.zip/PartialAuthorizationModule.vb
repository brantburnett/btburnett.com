﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' PartialAuthenticationSystem is distributed under the terms of the GNU Lesser General Public License (GPL)

' PartialAuthenticationSystem is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' PartialAuthenticationSystem is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with PartialAuthenticationSystem.  If not, see <http://www.gnu.org/licenses/>.

Imports System.Security.Principal
Imports System.Web.Configuration
Imports System.Web.Security

Public Class PartialAuthorizationModule
    Implements IHttpModule

    Public Sub Dispose() Implements System.Web.IHttpModule.Dispose
    End Sub

    Public Sub Init(ByVal context As System.Web.HttpApplication) Implements System.Web.IHttpModule.Init
        AddHandler context.AuthorizeRequest, AddressOf AuthorizeRequest
    End Sub

    Private Sub RedirectProtocol(ByVal context As HttpContext, ByVal protocol As String)
        Dim Url As Uri = context.Request.Url
        context.Response.Redirect(protocol & Url.AbsoluteUri.Substring(Url.Scheme.Length), True)
    End Sub

    Private Sub AuthorizeRequest(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim application As HttpApplication = sender
        Dim context As HttpContext = application.Context

        Dim section As PartialAuthorizationSection = WebConfigurationManager.GetSection("partialAuthenticationSystem/authorization", context.Request.Path)
        If section.RequireSSL = SslRequirement.None AndAlso context.Request.IsSecureConnection Then
            If Not context.Request.FilePath.EndsWith(".axd", StringComparison.InvariantCultureIgnoreCase) Then
                RedirectProtocol(context, "http")
                Exit Sub
            End If
        ElseIf section.RequireSSL = SslRequirement.Required AndAlso Not context.Request.IsSecureConnection Then
            RedirectProtocol(context, "https")
            Exit Sub
        End If

        If section.RequireLogin Then
            If context.User Is Nothing OrElse context.User.Identity Is Nothing Then
                FormsAuthentication.RedirectToLoginPage()
            ElseIf context.User.Identity.AuthenticationType = "Partial" Then
                FormsAuthentication.RedirectToLoginPage()
            End If
        End If
    End Sub

End Class
