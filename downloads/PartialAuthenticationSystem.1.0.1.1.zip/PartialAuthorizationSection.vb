﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' PartialAuthenticationSystem is distributed under the terms of the GNU Lesser General Public License (GPL)

' PartialAuthenticationSystem is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' PartialAuthenticationSystem is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with PartialAuthenticationSystem.  If not, see <http://www.gnu.org/licenses/>.

Imports System.Configuration
Imports System.Web.Configuration

Public Class PartialAuthorizationSection
    Inherits ConfigurationSection

    Private Shared _initialized As Boolean
    Private Shared _properties As New ConfigurationPropertyCollection()
    Private Shared _propRequireSSL As New ConfigurationProperty("requireSSL", GetType(SslRequirement), SslRequirement.Optional)
    Private Shared _propRequireLogin As New ConfigurationProperty("requireLogin", GetType(Boolean), False)

    Protected Overrides ReadOnly Property Properties() As System.Configuration.ConfigurationPropertyCollection
        Get
            If Not _initialized Then
                _properties.Add(_propRequireSSL)
                _properties.Add(_propRequireLogin)
            End If

            Return _properties
        End Get
    End Property

    <ConfigurationProperty("requireSSL", DefaultValue:=SslRequirement.Optional)> _
    Public Property RequireSSL() As SslRequirement
        Get
            Return Item(_propRequireSSL)
        End Get
        Set(ByVal value As SslRequirement)
            Item(_propRequireSSL) = value
        End Set
    End Property

    <ConfigurationProperty("requireLogin", DefaultValue:=False)> _
    Public Property RequireLogin() As Boolean
        Get
            Return Item(_propRequireLogin)
        End Get
        Set(ByVal value As Boolean)
            Item(_propRequireLogin) = value
        End Set
    End Property

End Class
