﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' PartialAuthenticationSystem is distributed under the terms of the GNU Lesser General Public License (GPL)

' PartialAuthenticationSystem is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' PartialAuthenticationSystem is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with PartialAuthenticationSystem.  If not, see <http://www.gnu.org/licenses/>.

Imports System.Security.Principal
Imports System.Web.Security

Public Class PartialAuthenticationModule
    Implements IHttpModule

    Public Sub Dispose() Implements System.Web.IHttpModule.Dispose
    End Sub

    Public Sub Init(ByVal context As System.Web.HttpApplication) Implements System.Web.IHttpModule.Init
        AddHandler context.AuthenticateRequest, AddressOf AuthenticateRequest
    End Sub

    Private Function GetTicket(ByVal context As HttpContext) As FormsAuthenticationTicket
        If PartialAuthentication.RequireSSL AndAlso Not context.Request.IsSecureConnection Then
            Return Nothing
        End If

        Dim cookie As HttpCookie = context.Request.Cookies(PartialAuthentication.IdentityCookieName)
        If cookie Is Nothing Then
            Return Nothing
        Else
            Try
                Return PartialAuthentication.Decrypt(cookie.Value)
            Catch
                Return Nothing
            End Try
        End If
    End Function

    Private Sub AuthenticateRequest(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim application As HttpApplication = sender
        Dim context As HttpContext = application.Context

        If context.User Is Nothing OrElse context.User.Identity Is Nothing Then
            Dim ticket As FormsAuthenticationTicket = GetTicket(context)
            If Not ticket Is Nothing Then
                Dim roleList As String() = Nothing
                If Roles.Enabled Then
                    roleList = Roles.GetRolesForUser(ticket.Name)
                End If

                context.User = New GenericPrincipal(New GenericIdentity(ticket.Name, "Partial"), roleList)

                PartialAuthentication.RenewTicketIfOld(context, ticket)
            End If
        Else 'Already have a user from forms authentication
            Dim ticket As FormsAuthenticationTicket = GetTicket(context)
            If Not ticket Is Nothing Then
                If ticket.Name <> context.User.Identity.Name Then
                    PartialAuthentication.SignOut(False)
                Else
                    PartialAuthentication.RenewTicketIfOld(context, ticket)
                End If
            End If
        End If
    End Sub

End Class
