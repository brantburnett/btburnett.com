﻿' Copyright (c) 2008 Pathfinder Software, LLC.  All Rights Reserved.
' Pathfinder Software <http://www.pfasoft.com>
' PartialAuthenticationSystem is distributed under the terms of the GNU Lesser General Public License (GPL)

' PartialAuthenticationSystem is free software: you can redistribute it and/or modify
' it under the terms of the GNU Lesser General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.

' PartialAuthenticationSystem is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public License
' along with PartialAuthenticationSystem.  If not, see <http://www.gnu.org/licenses/>.

Imports System.Configuration
Imports System.Web.Configuration

Public Class PartialAuthenticationSection
    Inherits ConfigurationSection

    Private Shared _initialized As Boolean
    Private Shared _properties As New ConfigurationPropertyCollection()
    Private Shared _propName As New ConfigurationProperty("name", GetType(String), ".ASPXIDENTITY")
    Private Shared _propTimeout As New ConfigurationProperty("timeout", GetType(Integer), 172800)
    Private Shared _propRequireSSL As New ConfigurationProperty("requireSSL", GetType(Boolean), False)

    Protected Overrides ReadOnly Property Properties() As System.Configuration.ConfigurationPropertyCollection
        Get
            If Not _initialized Then
                _properties.Add(_propName)
                _properties.Add(_propTimeout)
                _properties.Add(_propRequireSSL)
            End If

            Return _properties
        End Get
    End Property

    <ConfigurationProperty("name", DefaultValue:=".ASPXIDENTITY")> _
    Public Property Name() As String
        Get
            Return Item(_propName)
        End Get
        Set(ByVal value As String)
            Item(_propName) = value
        End Set
    End Property

    <ConfigurationProperty("timeout", DefaultValue:=172800)> _
    Public Property Timeout() As Integer
        Get
            Return Item(_propTimeout)
        End Get
        Set(ByVal value As Integer)
            Item(_propTimeout) = value
        End Set
    End Property

    <ConfigurationProperty("requireSSL", DefaultValue:=False)> _
    Public Property RequireSSL() As Boolean
        Get
            Return Item(_propRequireSSL)
        End Get
        Set(ByVal value As Boolean)
            Item(_propRequireSSL) = value
        End Set
    End Property

End Class
